"""Extract the Tamil Nadu check-in dataset used in the paper from LBSN2Vec++ (Yang et al., WWW 2019).

1. Download the LBSN2Vec++ release (doi:10.4121/15112308, CC BY 4.0), e.g. the figshare "Download all"
   zip (15112308.zip, ~2.7 GB). Nothing needs to be unzipped.
2. python scripts/extract_tamil_nadu.py path/to/15112308.zip

Steps: venues with country code IN whose coordinates lie inside the GADM Tamil Nadu polygon
(data/tamil_nadu_gadm.geojson) -> all raw check-ins at those venues -> core filter (POIs >= 5, users >= 10).
Outputs (data/): TN_Foursquare_LBSN_all.csv and TN_Foursquare_LBSN_core_u10_p5.csv, in the TSMC2014 column layout.
Requires: pandas, shapely.
"""
import sys, os, io, json, zipfile, csv
import pandas as pd
from shapely.geometry import shape, Point
from shapely.prepared import prep

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DATA = os.path.join(ROOT, "data")
src = sys.argv[1]
poly = prep(shape(json.load(open(os.path.join(DATA, "tamil_nadu_gadm.geojson")))["features"][0]["geometry"]))

z = zipfile.ZipFile(src)
inner = [n for n in z.namelist() if n.lower().endswith(".zip")]
Z = zipfile.ZipFile(z.open(inner[0])) if inner else z       # read the nested zip in place, no extraction
names = [n for n in Z.namelist() if not n.startswith("__MACOSX")]
poi_f = [n for n in names if n.endswith("raw_POIs.txt")][0]
raw_f = [n for n in names if n.endswith("raw_Checkins_anonymized.txt")][0]

def rows(name):
    with Z.open(name) as f:
        for line in io.TextIOWrapper(f, encoding="utf-8", errors="replace"):
            yield line.rstrip("\n").split("\t")

venues = {}
for r in rows(poi_f):                                      # venue, lat, lon, category, country
    if len(r) < 5 or r[4] != "IN":
        continue
    try:
        lat, lon = float(r[1]), float(r[2])
    except ValueError:
        continue
    if 8.0 <= lat <= 13.6 and 76.2 <= lon <= 80.4 and poly.contains(Point(lon, lat)):
        venues[r[0]] = (lat, lon, r[3])
print("Tamil Nadu venues:", len(venues))

out_all = os.path.join(DATA, "TN_Foursquare_LBSN_all.csv")
with open(out_all, "w", newline="", encoding="utf-8") as fo:
    w = csv.writer(fo)
    w.writerow(["userId", "venueId", "venueCategoryId", "venueCategory", "latitude", "longitude", "timezoneOffset", "utcTimestamp"])
    for r in rows(raw_f):                                  # user, venue, UTC time, timezone offset
        v = venues.get(r[1]) if len(r) >= 3 else None
        if v:
            w.writerow([r[0], r[1], v[2], v[2], v[0], v[1], r[3] if len(r) > 3 else "", r[2]])

d = pd.read_csv(out_all)
print(f"all: {len(d)} check-ins | {d.userId.nunique()} users | {d.venueId.nunique()} POIs")
for _ in range(30):
    n0 = len(d)
    d = d[d.venueId.map(d.venueId.value_counts()) >= 5]
    d = d[d.userId.map(d.userId.value_counts()) >= 10]
    if len(d) == n0:
        break
d.to_csv(os.path.join(DATA, "TN_Foursquare_LBSN_core_u10_p5.csv"), index=False)
print(f"core: {len(d)} check-ins | {d.userId.nunique()} users | {d.venueId.nunique()} POIs | {d.venueCategory.nunique()} categories")
