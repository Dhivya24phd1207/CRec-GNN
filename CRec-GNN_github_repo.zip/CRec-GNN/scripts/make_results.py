"""Build every results table and figure of the CRec-GNN paper from the per-seed result files (run from the repository root: python scripts/make_results.py).

Inputs (same folder): results_<DS>_v15.json (and results_<DS>_v17.json for the ablation), isrep_<DS>.npy
Outputs (parent folder): tab_main.tex, tab_repnov.tex, tab_revisit.tex, tab_sig.tex, tab_abl.tex, fig_revisit.pdf, fig_repnov.pdf
Run:  python make_results.py
"""
import json, os, numpy as np
from scipy.stats import wilcoxon
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
HERE = os.path.join(ROOT, "results"); OUT = os.path.join(ROOT, "paper_outputs"); os.makedirs(OUT, exist_ok=True)
DS = [("NYC", "NYC"), ("TKY", "Tokyo"), ("GOWALLA", "Gowalla"), ("TN", "Tamil Nadu")]
ND = len(DS)
MODELS = [  # (paper label, group, key)
    ("UserFreq", "main", "UserFreq"), ("Popularity", "main", "Popularity"),
    ("MF", "main", "MF"), ("GRU4Rec", "main", "GRU4Rec"), ("SASRec", "main", "SASRec"),
    ("GNN", "main", "GNN(Stable)"), ("GNN+ID", "main", "GNN(Stable)+ID"),
    ("MF+RA", "main", "MF+Rep"), ("SASRec+RA", "main", "SASRec+Rep"), ("GNN+ID+RA", "main", "GNN(Stable)+ID+Rep"),
    ("CRec-GNN", "abl_v15", "no_twin"),
]
FINAL = ("abl_v15", "no_twin")
J = {d: json.load(open(os.path.join(HERE, f"results_{d}_v15.json")))["runs"] for d, _ in DS}
J17 = {d: (json.load(open(p))["runs"] if os.path.exists(p := os.path.join(HERE, f"results_{d}_v17.json")) else {}) for d, _ in DS}
REP = {d: np.load(os.path.join(HERE, f"isrep_{d}.npy")) for d, _ in DS}

SEEDS = {d: [s for s in range(1, 6) if all(f"{g}/{k}/{s}" in J[d] for _, g, k in MODELS)] for d, _ in DS}  # seeds common to all models
def runs(d, g, k):
    src = J17[d] if g == "abl_v17" else J[d]
    return [src[f"{g}/{k}/{s}"] for s in SEEDS[d] if f"{g}/{k}/{s}" in src]
def val(d, g, k, proto, part, met):
    rr = runs(d, g, k)
    return (np.mean([r[proto][part][met] for r in rr]), np.std([r[proto][part][met] for r in rr]), len(rr)) if rr else (np.nan, np.nan, 0)
def per_user(d, g, k, key):
    rr = runs(d, g, k); rk = np.mean([np.array(r[key]) for r in rr], 0)
    return np.where(rk < 10, 1 / np.log2(rk + 2), 0.0)
def wil(d, a, b, key, mask=None):
    x, y = per_user(d, *a, key), per_user(d, *b, key)
    if mask is not None: x, y = x[mask], y[mask]
    return float((x - y).mean()), (float(wilcoxon(x, y).pvalue) if not np.allclose(x, y) else 1.0)
def seeds_note(d):
    return min(len(runs(d, g, k)) for _, g, k in MODELS)
def fmt_p(p):
    return "$<$0.001" if p < 1e-3 else f"{p:.3f}"
def cell(v, best, second):
    s = f"{v:.3f}"
    return r"\textbf{" + s + "}" if np.isclose(v, best) else (r"\underline{" + s + "}" if np.isclose(v, second) else s)

# ---------------- Table: main ----------------
cols = [("test_split", "HitRate@10", "HR"), ("test_split", "NDCG@10", "N"), ("test_full", "HitRate@10", "HR"), ("test_full", "NDCG@10", "N")]
L = [r"\begin{table*}[t]", r"\caption{Main results on the test targets, mean over five seeds (standard deviation $\leq$0.017 for every learned model). S: sampled protocol (99 negatives the user never visited); F: full-catalogue ranking. HR = HitRate@10, N = NDCG@10. Best per column in bold, second underlined. Models below the rule are ours: each backbone with the proposed revisit-aware (RA) layer, and CRec-GNN.}",
     r"\label{tab:main}", r"\centering\footnotesize", r"\setlength{\tabcolsep}{2.4pt}", r"\begin{tabular}{l" + "cccc" * ND + "}", r"\toprule"]
L.append(" & " + " & ".join([r"\multicolumn{4}{c}{" + n + (f" ({seeds_note(d)} seeds)" if seeds_note(d) < 5 else "") + "}" for d, n in DS]) + r" \\")
L.append(" ".join([r"\cmidrule(lr){%d-%d}" % (2 + 4 * i, 5 + 4 * i) for i in range(ND)]))
L.append("Model & " + " & ".join(["S-HR & S-N & F-HR & F-N"] * ND) + r" \\ \midrule"); L.append(r"\multicolumn{" + str(1 + 4 * ND) + r"}{l}{\textit{Baselines}} \\")
table = {(m, d, c): val(d, g, k, c[0], "all", c[1])[0] for m, g, k in MODELS for d, _ in DS for c in cols}
for m, g, k in MODELS:
    if m == "MF+RA": L += [r"\midrule", r"\multicolumn{" + str(1 + 4 * ND) + r"}{l}{\textit{Proposed (ours): RA layer on each backbone, and CRec-GNN}} \\"]
    row = [m]
    for d, _ in DS:
        for c in cols:
            colv = sorted([table[(mm, d, c)] for mm, _, _ in MODELS if not np.isnan(table[(mm, d, c)])], reverse=True)
            row.append(cell(table[(m, d, c)], colv[0], colv[1]))
    L.append(" & ".join(row) + r" \\")
L += [r"\bottomrule", r"\end{tabular}", r"\end{table*}"]
open(os.path.join(OUT, "tab_main.tex"), "w").write("\n".join(L))

# ---------------- Table: repeat vs novel ----------------
RN = [("UserFreq", "main", "UserFreq"), ("MF", "main", "MF"), ("SASRec", "main", "SASRec"), ("GNN+ID", "main", "GNN(Stable)+ID"),
      ("MF+RA", "main", "MF+Rep"), ("SASRec+RA", "main", "SASRec+Rep"), ("GNN+ID+RA", "main", "GNN(Stable)+ID+Rep"), ("CRec-GNN", *FINAL)]
L = [r"\begin{table*}[t]", r"\caption{NDCG@10 on repeat targets (the user visited the POI in training) and novel targets, under the sampled (S) and full-catalogue (F) protocols, mean over seeds. Best per column in bold.}",
     r"\label{tab:repnov}", r"\centering\footnotesize", r"\setlength{\tabcolsep}{2.4pt}", r"\begin{tabular}{l" + "cccc" * ND + "}", r"\toprule"]
L.append(" & " + " & ".join([r"\multicolumn{4}{c}{" + n + f" (repeat {REP[d].mean()*100:.1f}\\%)" + "}" for d, n in DS]) + r" \\")
L.append(" ".join([r"\cmidrule(lr){%d-%d}" % (2 + 4 * i, 5 + 4 * i) for i in range(ND)]))
L.append("Model & " + " & ".join(["S-rep & S-nov & F-rep & F-nov"] * ND) + r" \\ \midrule"); L.append(r"\multicolumn{" + str(1 + 4 * ND) + r"}{l}{\textit{Baselines}} \\")
rc = [("test_split", "repeat"), ("test_split", "novel"), ("test_full", "repeat"), ("test_full", "novel")]
tv = {(m, d, c): val(d, g, k, c[0], c[1], "NDCG@10")[0] for m, g, k in RN for d, _ in DS for c in rc}
for m, g, k in RN:
    if m == "MF+RA": L += [r"\midrule", r"\multicolumn{" + str(1 + 4 * ND) + r"}{l}{\textit{Proposed (ours): RA layer on each backbone, and CRec-GNN}} \\"]
    row = [m]
    for d, _ in DS:
        for c in rc:
            best = max(tv[(mm, d, c)] for mm, _, _ in RN)
            v = tv[(m, d, c)]; s = f"{v:.3f}"
            row.append(r"\textbf{" + s + "}" if np.isclose(v, best) else s)
    L.append(" & ".join(row) + r" \\")
L += [r"\bottomrule", r"\end{tabular}", r"\end{table*}"]
open(os.path.join(OUT, "tab_repnov.tex"), "w").write("\n".join(L))

# ---------------- Table: effect of the revisit term ----------------
PAIRS = [("MF", ("main", "MF"), ("main", "MF+Rep")), ("SASRec", ("main", "SASRec"), ("main", "SASRec+Rep")),
         ("GNN+ID", ("main", "GNN(Stable)+ID"), ("main", "GNN(Stable)+ID+Rep"))]
L = [r"\begin{table}[t]", r"\caption{Effect of the proposed RA layer on each backbone: full-catalogue NDCG@10 of the backbone alone $\rightarrow$ with RA, relative gain, mean per-user difference {\unboldmath$\Delta$}, and Wilcoxon $p$ (per-user, seed-averaged ranks).}",
     r"\label{tab:revisit}", r"\centering\small", r"\setlength{\tabcolsep}{3pt}", r"\begin{tabular}{llcccc}", r"\toprule", r"Dataset & Backbone & F-NDCG@10 & Gain & $\Delta$ & $p$ \\ \midrule"]
for d, n in DS:
    for i, (fam, a, b) in enumerate(PAIRS):
        va, vb = val(d, *a, "test_full", "all", "NDCG@10")[0], val(d, *b, "test_full", "all", "NDCG@10")[0]
        diff, p = wil(d, b, a, "test_full_rank")
        L.append(f"{n if i == 0 else ''} & {fam} & {va:.3f} $\\rightarrow$ {vb:.3f} & {100*(vb-va)/va:+.0f}\\% & {diff:+.3f} & {fmt_p(p)} \\\\")
    if d != DS[-1][0]: L.append(r"\midrule")
L += [r"\bottomrule", r"\end{tabular}", r"\end{table}"]
open(os.path.join(OUT, "tab_revisit.tex"), "w").write("\n".join(L))

# ---------------- Table: CRec-GNN vs baselines (significance) ----------------
VS = [("UserFreq", ("main", "UserFreq")), ("MF+RA", ("main", "MF+Rep")), ("SASRec+RA", ("main", "SASRec+Rep")), ("GNN+ID+RA", ("main", "GNN(Stable)+ID+Rep"))]
L = [r"\begin{table}[t]", r"\caption{CRec-GNN minus each comparison model: mean per-user NDCG@10 difference and two-sided Wilcoxon signed-rank $p$ on seed-averaged ranks (positive: CRec-GNN better).}",
     r"\label{tab:sig}", r"\centering\small", r"\setlength{\tabcolsep}{3pt}", r"\begin{tabular}{llcccc}", r"\toprule", r"& & \multicolumn{2}{c}{Sampled} & \multicolumn{2}{c}{Full} \\ \cmidrule(lr){3-4}\cmidrule(lr){5-6}", r"Dataset & vs. & $\Delta$ & $p$ & $\Delta$ & $p$ \\ \midrule"]
for d, n in DS:
    for i, (lab, b) in enumerate(VS):
        ds_, ps_ = wil(d, FINAL, b, "test_rank"); df_, pf_ = wil(d, FINAL, b, "test_full_rank")
        L.append(f"{n if i == 0 else ''} & {lab} & {ds_:+.3f} & {fmt_p(ps_)} & {df_:+.3f} & {fmt_p(pf_)} \\\\")
    if d != DS[-1][0]: L.append(r"\midrule")
L += [r"\bottomrule", r"\end{tabular}", r"\end{table}"]
open(os.path.join(OUT, "tab_sig.tex"), "w").write("\n".join(L))

# ---------------- Table: ablation (needs v17) ----------------
ABL = [("+ state-feedback rollout", ("main", "SF+ID+RepTwin")), ("$-$ RA layer", ("abl_v17", "no_repeat")), ("constant $\\pi$", ("abl_v17", "const_pi")),
       ("$-$ category conditioning", ("abl_v17", "no_constraint")), ("$-$ decoder gate", ("abl_v17", "no_gate"))]
L = [r"\begin{table}[t]", r"\caption{Ablation of CRec-GNN: full-catalogue (F) and sampled (S) NDCG@10 of each variant and per-user Wilcoxon $p$ against CRec-GNN.}",
     r"\label{tab:abl}", r"\centering\small", r"\setlength{\tabcolsep}{2.5pt}", r"\begin{tabular}{llcccc}", r"\toprule", r"Dataset & Variant & S-N & $p_S$ & F-N & $p_F$ \\ \midrule"]
for d, n in DS:
    L.append(f"{n} & CRec-GNN & {val(d, *FINAL, 'test_split', 'all', 'NDCG@10')[0]:.3f} & -- & {val(d, *FINAL, 'test_full', 'all', 'NDCG@10')[0]:.3f} & -- \\\\")
    for lab, b in ABL:
        if not runs(d, *b):
            L.append(f" & {lab} & \\multicolumn{{4}}{{c}}{{\\todo{{v17 run pending}}}} \\\\"); continue
        _, ps_ = wil(d, FINAL, b, "test_rank"); _, pf_ = wil(d, FINAL, b, "test_full_rank")
        L.append(f" & {lab} & {val(d, *b, 'test_split', 'all', 'NDCG@10')[0]:.3f} & {fmt_p(ps_)} & {val(d, *b, 'test_full', 'all', 'NDCG@10')[0]:.3f} & {fmt_p(pf_)} \\\\")
    if d != DS[-1][0]: L.append(r"\midrule")
L += [r"\bottomrule", r"\end{tabular}", r"\end{table}"]
open(os.path.join(OUT, "tab_abl.tex"), "w").write("\n".join(L))

# ---------------- Figures ----------------
plt.rcParams.update({"font.family": "serif", "font.size": 8, "axes.spines.top": False, "axes.spines.right": False,
                     "axes.edgecolor": "#52514e", "axes.labelcolor": "#0b0b0b", "xtick.color": "#52514e", "ytick.color": "#52514e"})
C = {"MF": "#2a78d6", "SASRec": "#eb6834", "GNN+ID": "#1baf7a", "CRec-GNN": "#6250d6"}

# Fig: revisit effect (arrows base -> +Rep), UserFreq reference line, CRec-GNN point
fig, axes = plt.subplots(2, ND, figsize=(7.16, 4.1))
for j, (d, n) in enumerate(DS):
    for i, (proto, plab) in enumerate((("test_split", "Sampled"), ("test_full", "Full catalogue"))):
        ax = axes[i, j]
        uf = val(d, "main", "UserFreq", proto, "all", "NDCG@10")[0]
        ax.axhline(uf, color="#52514e", lw=1, ls="--"); ax.text(-0.45, uf, "UserFreq", va="bottom", ha="left", fontsize=6.3, color="#52514e")
        for x, (fam, a, b) in enumerate(PAIRS):
            va, vb = val(d, *a, proto, "all", "NDCG@10")[0], val(d, *b, proto, "all", "NDCG@10")[0]
            ax.plot([x], [va], "o", ms=5, mfc="white", mec=C[fam], mew=1.5)
            ax.annotate("", xy=(x, vb), xytext=(x, va), arrowprops=dict(arrowstyle="-|>", color=C[fam], lw=1.5))
            ax.plot([x], [vb], "o", ms=5, color=C[fam])
        vc = val(d, *FINAL, proto, "all", "NDCG@10")[0]
        ax.plot([3], [vc], "D", ms=5.5, color=C["CRec-GNN"])
        ax.set_xticks(range(4)); ax.set_xticklabels(["MF", "SAS-\nRec", "GNN\n+ID", "CRec-\nGNN"], fontsize=6)
        ax.set_xlim(-0.5, 3.5); ax.grid(axis="y", color="#e6e5e0", lw=0.6); ax.set_axisbelow(True)
        if j == 0: ax.set_ylabel(f"{plab}\nNDCG@10")
        if i == 0: ax.set_title(n + (f" ({seeds_note(d)} seeds)" if seeds_note(d) < 5 else ""), fontsize=8.5)
fig.text(0.5, 0.005, "open circle: backbone alone   $\\rightarrow$   filled: with the proposed RA layer      $\\diamond$ CRec-GNN      dashed: UserFreq (no learning)",
         ha="center", fontsize=6.8, color="#52514e")
plt.tight_layout(rect=(0, 0.04, 1, 1)); plt.savefig(os.path.join(OUT, "fig_revisit.pdf")); plt.savefig(os.path.join(OUT, "fig_revisit.png"), dpi=300); plt.close()

# Fig: repeat vs novel, sampled protocol, grouped bars
GR = [("UserFreq", "main", "UserFreq", "#b9b8b2"), ("MF+RA", "main", "MF+Rep", C["MF"]), ("SASRec+RA", "main", "SASRec+Rep", C["SASRec"]),
      ("GNN+ID+RA", "main", "GNN(Stable)+ID+Rep", C["GNN+ID"]), ("CRec-GNN", *FINAL, C["CRec-GNN"])]
fig, axes = plt.subplots(1, 2, figsize=(7.16, 2.3), sharey=False)
w = 0.16
for a_i, (part, plab) in enumerate((("repeat", "Repeat targets"), ("novel", "Novel targets"))):
    ax = axes[a_i]
    for m_i, (m, g, k, col) in enumerate(GR):
        xs = np.arange(ND) + (m_i - 2) * (w + 0.012)
        vs_ = [val(d, g, k, "test_split", part, "NDCG@10")[0] for d, _ in DS]
        ax.bar(xs, vs_, width=w, color=col, label=m, linewidth=0)
    ax.set_xticks(range(ND)); ax.set_xticklabels([n for _, n in DS]); ax.set_title(plab + " (sampled protocol)", fontsize=8.5)
    ax.grid(axis="y", color="#e6e5e0", lw=0.6); ax.set_axisbelow(True)
    if a_i == 0: ax.set_ylabel("NDCG@10")
axes[1].legend(fontsize=6.5, frameon=False, ncol=1, loc="upper left", bbox_to_anchor=(1.0, 1.0))
plt.tight_layout(); plt.savefig(os.path.join(OUT, "fig_repnov.pdf")); plt.savefig(os.path.join(OUT, "fig_repnov.png"), dpi=300); plt.close()

# numbers quoted in the text
Q = {}
for d, n in DS:
    Q[d] = {m: {p: round(val(d, g, k, p, "all", "NDCG@10")[0], 4) for p in ("test_split", "test_full")} for m, g, k in MODELS}
    Q[d]["seeds"] = seeds_note(d)
json.dump(Q, open(os.path.join(HERE, "quoted_numbers.json"), "w"), indent=1)
print(json.dumps({d: Q[d]["seeds"] for d, _ in DS}))

# ---------------- Extra figures: training curves, significance heatmap, metrics vs K ----------------
from matplotlib.colors import LinearSegmentedColormap
CURVE_M = [("MF+RA", ("main", "MF+Rep"), C["MF"]), ("SASRec+RA", ("main", "SASRec+Rep"), C["SASRec"]),
           ("GNN+ID+RA", ("main", "GNN(Stable)+ID+Rep"), C["GNN+ID"]), ("CRec-GNN", FINAL, C["CRec-GNN"])]
fig, axes = plt.subplots(2, ND, figsize=(7.16, 3.6), sharex=True)
for j, (d, n) in enumerate(DS):
    for m, (g, k), col in CURVE_M:
        rr = runs(d, g, k)
        if not rr or not rr[0].get("curve"): continue
        ep = np.array([c["epoch"] for c in rr[0]["curve"]])
        for i, key in enumerate(("loss", "val_ndcg10")):
            Y = np.array([[c[key] for c in r["curve"]] for r in rr]); mu, sd = Y.mean(0), Y.std(0)
            ax = axes[i, j]; ax.plot(ep, mu, color=col, lw=1.6, label=m); ax.fill_between(ep, mu - sd, mu + sd, color=col, alpha=0.15, lw=0)
    axes[0, j].set_title(n, fontsize=8.5)
    for i in range(2): axes[i, j].grid(axis="y", color="#e6e5e0", lw=0.6); axes[i, j].set_axisbelow(True)
    axes[1, j].set_xlabel("epoch")
axes[0, 0].set_ylabel("training BPR loss"); axes[1, 0].set_ylabel("validation\nsampled NDCG@10")
h, l = axes[0, 0].get_legend_handles_labels()
fig.legend(h, l, loc="lower center", ncol=4, frameon=False, fontsize=7)
plt.tight_layout(rect=(0, 0.06, 1, 1)); plt.savefig(os.path.join(OUT, "fig_curves.pdf")); plt.savefig(os.path.join(OUT, "fig_curves.png"), dpi=300); plt.close()

HM = [("UserFreq", ("main", "UserFreq")), ("Popularity", ("main", "Popularity")), ("MF", ("main", "MF")), ("GRU4Rec", ("main", "GRU4Rec")),
      ("SASRec", ("main", "SASRec")), ("GNN", ("main", "GNN(Stable)")), ("GNN+ID", ("main", "GNN(Stable)+ID")),
      ("MF+RA", ("main", "MF+Rep")), ("SASRec+RA", ("main", "SASRec+Rep")), ("GNN+ID+RA", ("main", "GNN(Stable)+ID+Rep"))]
cols_hm = [(d, n, key, lab) for d, n in DS for key, lab in (("test_rank", "S"), ("test_full_rank", "F"))]
D_ = np.zeros((len(HM), len(cols_hm))); P_ = np.ones_like(D_)
for i, (m, b) in enumerate(HM):
    for j, (d, n, key, lab) in enumerate(cols_hm):
        D_[i, j], P_[i, j] = wil(d, FINAL, b, key)
cmap = LinearSegmentedColormap.from_list("div", ["#c8423c", "#f0efec", "#2a78d6"])
lim = 0.30
fig, ax = plt.subplots(figsize=(7.16, 3.2))
im = ax.imshow(np.clip(D_, -lim, lim), cmap=cmap, vmin=-lim, vmax=lim, aspect="auto")
for i in range(D_.shape[0]):
    for j in range(D_.shape[1]):
        star = "*" if P_[i, j] < 0.05 else ""
        ax.text(j, i, f"{D_[i, j]:+.3f}{star}", ha="center", va="center", fontsize=6, color="#0b0b0b")
ax.set_yticks(range(len(HM))); ax.set_yticklabels([m for m, _ in HM], fontsize=7)
ax.set_xticks(range(len(cols_hm))); ax.set_xticklabels([f"{n}\n{lab}" for _, n, _, lab in cols_hm], fontsize=6.5)
ax.axhline(6.5, color="white", lw=2)
for j in range(1, ND): ax.axvline(2 * j - 0.5, color="white", lw=2)
ax.tick_params(length=0)
for s in ax.spines.values(): s.set_visible(False)
cb = fig.colorbar(im, ax=ax, fraction=0.025, pad=0.01); cb.ax.tick_params(labelsize=6); cb.set_label("CRec-GNN minus model (NDCG@10)", fontsize=6.5)
plt.tight_layout(); plt.savefig(os.path.join(OUT, "fig_heatmap.pdf")); plt.savefig(os.path.join(OUT, "fig_heatmap.png"), dpi=300); plt.close()

KM = [("UserFreq", ("main", "UserFreq"), "#8a8984")] + CURVE_M
fig, axes = plt.subplots(1, ND, figsize=(7.16, 2.2))
for j, (d, n) in enumerate(DS):
    ax = axes[j]
    for m, (g, k), col in KM:
        ys = [val(d, g, k, "test_full", "all", f"NDCG@{K}")[0] for K in (5, 10, 20)]
        ax.plot([5, 10, 20], ys, marker="o", color=col, lw=1.6, ms=3.5, label=m, ls="--" if m == "UserFreq" else "-")
    ax.set_xticks([5, 10, 20]); ax.set_title(n, fontsize=8.5); ax.set_xlabel("K"); ax.grid(axis="y", color="#e6e5e0", lw=0.6); ax.set_axisbelow(True)
axes[0].set_ylabel("full-catalogue NDCG@K")
h, l = axes[0].get_legend_handles_labels()
fig.legend(h, l, loc="lower center", ncol=5, frameon=False, fontsize=7)
plt.tight_layout(rect=(0, 0.1, 1, 1)); plt.savefig(os.path.join(OUT, "fig_topk.pdf")); plt.savefig(os.path.join(OUT, "fig_topk.png"), dpi=300); plt.close()
print("extra figures done")

# ---------------- Fig: performance by user activity (tertiles of training check-ins) ----------------
ACT_M = [("UserFreq", ("main", "UserFreq"), "#8a8984")] + CURVE_M
fig, axes = plt.subplots(1, ND, figsize=(7.16, 2.3))
ACT_Q = {}
for j, (d, n) in enumerate(DS):
    ntr = np.load(os.path.join(HERE, f"ntrain_{d}.npy")); q = np.quantile(ntr, [1 / 3, 2 / 3])
    b = np.digitize(ntr, q, right=True); ACT_Q[d] = [int(ntr.min()), int(q[0]), int(q[1]), int(ntr.max())]
    ax = axes[j]; w = 0.15
    for m_i, (m, (g, k), col) in enumerate(ACT_M):
        rr = runs(d, g, k)
        nd = np.mean([np.where(np.array(r["test_full_rank"]) < 10, 1 / np.log2(np.array(r["test_full_rank"]) + 2), 0.0) for r in rr], 0)
        ys = [nd[b == t].mean() for t in range(3)]
        ax.bar(np.arange(3) + (m_i - 2) * (w + 0.01), ys, width=w, color=col, label=m, linewidth=0)
    lab = [f"low\n{ACT_Q[d][0]}-{ACT_Q[d][1]}", f"mid\n{ACT_Q[d][1]+1}-{ACT_Q[d][2]}", f"high\n>{ACT_Q[d][2]}"]
    ax.set_xticks(range(3)); ax.set_xticklabels(lab, fontsize=6); ax.set_title(n, fontsize=8.5)
    ax.grid(axis="y", color="#e6e5e0", lw=0.6); ax.set_axisbelow(True)
axes[0].set_ylabel("full-catalogue NDCG@10")
h, l = axes[0].get_legend_handles_labels(); fig.legend(h, l, loc="lower center", ncol=5, frameon=False, fontsize=7)
plt.tight_layout(rect=(0, 0.1, 1, 1)); plt.savefig(os.path.join(OUT, "fig_activity.pdf")); plt.savefig(os.path.join(OUT, "fig_activity.png"), dpi=300); plt.close()
json.dump(ACT_Q, open(os.path.join(HERE, "activity_tertiles.json"), "w"))

# ---------------- Fig: ablation heatmap (variant minus CRec-GNN) ----------------
ABL_F = [("$-$ RA layer", ("abl_v17", "no_repeat")), ("constant $\\pi$", ("abl_v17", "const_pi")),
         ("$-$ category cond.", ("abl_v17", "no_constraint")), ("$-$ decoder gate", ("abl_v17", "no_gate")),
         ("+ state-feedback", ("main", "SF+ID+RepTwin"))]
if all(runs(d, *ABL_F[0][1]) for d, _ in DS):
    A_ = np.zeros((len(ABL_F), len(cols_hm))); Pa = np.ones_like(A_)
    for i, (lab, b) in enumerate(ABL_F):
        for j, (d, n, key, _) in enumerate(cols_hm):
            dd, pp = wil(d, b, FINAL, key); A_[i, j], Pa[i, j] = dd, pp
    lim2 = 0.06
    fig, ax = plt.subplots(figsize=(7.16, 1.9))
    im = ax.imshow(np.clip(A_, -lim2, lim2), cmap=cmap, vmin=-lim2, vmax=lim2, aspect="auto")
    for i in range(A_.shape[0]):
        for j in range(A_.shape[1]):
            ax.text(j, i, f"{A_[i, j]:+.3f}" + ("*" if Pa[i, j] < 0.05 else ""), ha="center", va="center", fontsize=6.3, color="#0b0b0b")
    ax.set_yticks(range(len(ABL_F))); ax.set_yticklabels([l for l, _ in ABL_F], fontsize=7)
    ax.set_xticks(range(len(cols_hm))); ax.set_xticklabels([f"{n}\n{lab}" for _, n, _, lab in cols_hm], fontsize=6.5)
    for j in range(1, ND): ax.axvline(2 * j - 0.5, color="white", lw=2)
    ax.tick_params(length=0)
    for s_ in ax.spines.values(): s_.set_visible(False)
    cb = fig.colorbar(im, ax=ax, fraction=0.025, pad=0.01); cb.ax.tick_params(labelsize=6); cb.set_label("variant minus CRec-GNN", fontsize=6.5)
    plt.tight_layout(); plt.savefig(os.path.join(OUT, "fig_ablation.pdf")); plt.savefig(os.path.join(OUT, "fig_ablation.png"), dpi=300); plt.close()
    print("ablation fig done")

# ---------------- Fig: Tamil Nadu dataset map ----------------
import pandas as pd
gj = json.load(open(os.path.join(HERE, "south_india_gadm.geojson")))
_tnp = os.path.join(ROOT, "data", "TN_Foursquare_LBSN_core_u10_p5.csv")
if not os.path.exists(_tnp):
    print("TN map skipped: run scripts/extract_tamil_nadu.py first"); import sys; sys.exit(0)
tn = pd.read_csv(_tnp)
pc = tn.groupby("venueId").agg(lat=("latitude", "first"), lon=("longitude", "first"), n=("userId", "size"))
def rings(geom):
    polys = geom["coordinates"] if geom["type"] == "MultiPolygon" else [geom["coordinates"]]
    for poly in polys:
        yield np.array(poly[0])
fig, ax = plt.subplots(figsize=(3.4, 3.6))
for f in gj["features"]:
    is_tn = f["properties"]["NAME_1"] == "Tamil Nadu"
    for r in rings(f["geometry"]):
        ax.fill(r[:, 0], r[:, 1], color="#f0efec" if is_tn else "#fafaf8", ec="#52514e" if is_tn else "#c9c8c2", lw=0.8 if is_tn else 0.4, zorder=1)
sc = ax.scatter(pc.lon, pc.lat, s=2 + 2.5 * np.sqrt(pc.n), c="#2a78d6", alpha=0.55, lw=0, zorder=3)
for nm, (la, lo) in {"Chennai": (13.08, 80.27), "Coimbatore": (11.02, 76.96), "Madurai": (9.93, 78.12), "Tiruchirappalli": (10.80, 78.69)}.items():
    ax.annotate(nm, (lo, la), xytext=(4, 3), textcoords="offset points", fontsize=6.5, color="#0b0b0b", zorder=4)
ax.set_xlim(76.0, 80.6); ax.set_ylim(7.9, 13.7); ax.set_aspect("equal")
ax.set_xlabel("longitude"); ax.set_ylabel("latitude"); ax.tick_params(labelsize=6.5)
for sz in (5, 50, 500):
    ax.scatter([], [], s=2 + 2.5 * np.sqrt(sz), c="#2a78d6", alpha=0.55, lw=0, label=f"{sz} check-ins")
ax.legend(fontsize=6, frameon=False, loc="upper left", title="POI", title_fontsize=6)
plt.tight_layout(); plt.savefig(os.path.join(OUT, "fig_tnmap.pdf")); plt.savefig(os.path.join(OUT, "fig_tnmap.png"), dpi=300); plt.close()
print("activity + map done", ACT_Q)

